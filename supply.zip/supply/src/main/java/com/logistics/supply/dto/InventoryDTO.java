package com.logistics.supply.dto;

import lombok.Getter;

@Getter
public class InventoryDTO {
    private String name;
}
