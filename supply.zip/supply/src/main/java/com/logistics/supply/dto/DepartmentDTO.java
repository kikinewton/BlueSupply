package com.logistics.supply.dto;

import lombok.Getter;

@Getter
public class DepartmentDTO {

    private String name;
    private String description;
}
